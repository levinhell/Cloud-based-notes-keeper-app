from flask import Flask, render_template, request, redirect
import firebase_admin
from firebase_admin import credentials, db
import uuid

app = Flask(__name__)

# Initialize Firebase
cred = credentials.Certificate("firebase_config.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://<your-database-name>.firebaseio.com/'
})

@app.route('/')
def index():
    ref = db.reference('/notes')
    notes = ref.get() or {}
    return render_template("index.html", notes=notes)

@app.route('/add', methods=['POST'])
def add_note():
    title = request.form['title']
    content = request.form['content']
    note_id = str(uuid.uuid4())
    ref = db.reference('/notes')
    ref.child(note_id).set({
        'title': title,
        'content': content
    })
    return redirect('/')

@app.route('/delete/<note_id>')
def delete_note(note_id):
    ref = db.reference('/notes')
    ref.child(note_id).delete()
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)